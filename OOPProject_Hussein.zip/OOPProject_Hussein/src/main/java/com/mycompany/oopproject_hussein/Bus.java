package com.mycompany.oopproject_hussein;
import java.io.Serializable;

public class Bus extends Car implements  Serializable {
    private int capacity;

    public Bus(String name, String color, int chassisNumber, int id, double regularRentingPrice, int maxAllowedRentings, int capacity) {
        super(name, color, chassisNumber, id, regularRentingPrice, maxAllowedRentings);
        this.capacity = capacity;
    }

    // Getters and Setters
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    
    
/*This method overrides a method from the parent class (probably an abstract method in a Car or Vehicle class),
    and returns a double value that represents the dynamic rental price of the bus depending on its capacity*/
    @Override
    public double calculatePrice() {
        return getRegularRentingPrice() * Math.max(0.5, 1 - capacity / 100.0);
    // the Math.max 0.5 is to never goes below 0.5 (50% of base price) to prevent -ve sign .
    }

    @Override
    public String toString() {
        return "Bus{" +
                "capacity=" + capacity +
                "} " + super.toString();
    }
}