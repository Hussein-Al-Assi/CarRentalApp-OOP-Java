package com.mycompany.oopproject_hussein;

import java.io.Serializable;

public class Client implements Serializable {
    private String name;
    private int ssn;
    private String phone;
    private String address;

    public Client(String name, int ssn, String phone, String address) {
        this.name = name;
        this.ssn = ssn;
        this.phone = phone;
        this.address = address;
    }

    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getSsn() { return ssn; }
    public void setSsn(int ssn) { this.ssn = ssn; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    @Override
    public String toString() {
        return "Client{" +
                "name='" + name + '\'' +
                ", ssn=" + ssn +
                ", phone='" + phone + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}