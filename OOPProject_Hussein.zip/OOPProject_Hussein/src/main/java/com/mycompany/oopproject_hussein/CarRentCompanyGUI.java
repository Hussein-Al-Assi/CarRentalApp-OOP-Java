package com.mycompany.oopproject_hussein;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class CarRentCompanyGUI {
    private JFrame frame;
    private JPanel cardPanel;
    private CardLayout cardLayout;
    private ArrayList<Client> clients;
    private ArrayList<Car> cars;
    private JComboBox<Car> carComboBox;
    private Client activeClient;
    private JTextArea textArea;

    public CarRentCompanyGUI(ArrayList<Client> clients, ArrayList<Car> cars) {
        this.clients = clients;
        this.cars = cars;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Car Rent Company");
        frame.setBounds(100, 100, 800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // CardLayout to switch between panels
        cardPanel = new JPanel();
        cardLayout = new CardLayout();
        cardPanel.setLayout(cardLayout);
        frame.add(cardPanel, BorderLayout.CENTER);

        // Splash Screen
        JPanel splashPanel = new JPanel();
        splashPanel.setLayout(new BorderLayout());
        splashPanel.setBackground(Color.WHITE);

        JLabel welcomeLabel = new JLabel("Welcome to the Car Rent Company Management System!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setForeground(new Color(0x333333));
        splashPanel.add(welcomeLabel, BorderLayout.CENTER);

        // Add logo image
        JLabel logoLabel = new JLabel(new ImageIcon("logo.png"));
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        splashPanel.add(logoLabel, BorderLayout.NORTH);

        JButton startButton = new JButton("Start");
        startButton.setFont(new Font("Arial", Font.PLAIN, 16));
        startButton.setBackground(new Color(0x007BFF));
        startButton.setForeground(Color.WHITE);
        startButton.setFocusPainted(false);
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.next(cardPanel);
            }
        });
        splashPanel.add(startButton, BorderLayout.SOUTH);
        cardPanel.add(splashPanel, "Splash");

        //    Client Management Screen
        JPanel clientManagementPanel = new JPanel();
        clientManagementPanel.setLayout(new BorderLayout());
        clientManagementPanel.setBackground(Color.WHITE);
        clientManagementPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        //   Login Section
        JPanel loginPanel = new JPanel();
        loginPanel.setBorder(BorderFactory.createTitledBorder("Existing Client Login"));
        loginPanel.setLayout(new GridLayout(3, 2, 10, 10));
        loginPanel.setBackground(Color.WHITE);

        JLabel loginLabel = new JLabel("SSN:");
        loginLabel.setForeground(new Color(0x333333));
        JTextField loginSSNField = new JTextField();
        JButton loginButton = new JButton("Login");
        loginButton.setBackground(new Color(0x007BFF));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        JButton backButton = new JButton("Back");
        backButton.setBackground(new Color(0x007BFF));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);

        loginPanel.add(loginLabel);
        loginPanel.add(loginSSNField);
        loginPanel.add(new JLabel()); // Empty label for alignment
        loginPanel.add(loginButton);
        loginPanel.add(new JLabel()); // Empty label for alignment
        loginPanel.add(backButton);
        clientManagementPanel.add(loginPanel, BorderLayout.NORTH);

        // Register Section 
        JPanel registerPanel = new JPanel();
        registerPanel.setBorder(BorderFactory.createTitledBorder("New Client Registration"));
        registerPanel.setLayout(new GridLayout(6, 2, 10, 10));
        registerPanel.setBackground(Color.WHITE);

        JLabel registerNameLabel = new JLabel("Name:");
        registerNameLabel.setForeground(new Color(0x333333));
        JTextField registerNameField = new JTextField();
        JLabel registerSSNLabel = new JLabel("SSN:");
        registerSSNLabel.setForeground(new Color(0x333333));
        JTextField registerSSNField = new JTextField();
        JLabel registerPhoneLabel = new JLabel("Phone:");
        registerPhoneLabel.setForeground(new Color(0x333333));
        JTextField registerPhoneField = new JTextField();
        JLabel registerAddressLabel = new JLabel("Address:");
        registerAddressLabel.setForeground(new Color(0x333333));
        JTextField registerAddressField = new JTextField();
        JButton registerButton = new JButton("Register");
        registerButton.setBackground(new Color(0x007BFF));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);

        registerPanel.add(registerNameLabel);
        registerPanel.add(registerNameField);
        registerPanel.add(registerSSNLabel);
        registerPanel.add(registerSSNField);
        registerPanel.add(registerPhoneLabel);
        registerPanel.add(registerPhoneField);
        registerPanel.add(registerAddressLabel);
        registerPanel.add(registerAddressField);
        registerPanel.add(new JLabel()); // Empty label for alignment
        registerPanel.add(registerButton);
        clientManagementPanel.add(registerPanel, BorderLayout.CENTER);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String ssnText = loginSSNField.getText();
                try {
                    int ssn = Integer.parseInt(ssnText);
                    for (Client client : clients) {
                        if (client.getSsn() == ssn) {
                            showMainApplicationPanel(client);
                            return;
                        }
                    }
                    JOptionPane.showMessageDialog(frame, "Invalid SSN. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid SSN format. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = registerNameField.getText();
                String ssnText = registerSSNField.getText();
                String phone = registerPhoneField.getText();
                String address = registerAddressField.getText();
                if (name.isEmpty() || ssnText.isEmpty() || phone.isEmpty() || address.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                    int ssn = Integer.parseInt(ssnText);
                    for (Client client : clients) {
                        if (client.getSsn() == ssn) {
                            JOptionPane.showMessageDialog(frame, "SSN already exists. Please use a different SSN.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                    }
                    Client newClient = new Client(name, ssn, phone, address);
                    clients.add(newClient);
                    JOptionPane.showMessageDialog(frame, "Registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    showMainApplicationPanel(newClient);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid SSN format. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.first(cardPanel);
            }
        });

        cardPanel.add(clientManagementPanel, "ClientManagement");

        // Main Application Screen
        JPanel mainApplicationPanel = new JPanel();
        mainApplicationPanel.setLayout(new BorderLayout());
        mainApplicationPanel.setBackground(Color.WHITE);
        mainApplicationPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

       textArea = new JTextArea(6, 30);  // 6 rows visible, 30 columns wide
textArea.setEditable(false);
textArea.setBackground(new Color(0xF0F0F0));
textArea.setForeground(new Color(0x333333));

// Create a scroll pane with preferred size
JScrollPane scrollPane = new JScrollPane(textArea);
scrollPane.setPreferredSize(new Dimension(0, 250)); 

// Create a container panel with BorderLayout
JPanel textContainer = new JPanel(new BorderLayout());
textContainer.add(scrollPane, BorderLayout.CENTER);

// Add to main panel using PAGE_START instead of CENTER
mainApplicationPanel.add(textContainer, BorderLayout.PAGE_START);  

        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new BorderLayout());
        controlPanel.setBackground(Color.WHITE);

        JPanel carSelectionPanel = new JPanel();
        carSelectionPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        carSelectionPanel.setBackground(Color.WHITE);
        carSelectionPanel.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 10)); // Lifts up by 20 pixels to be sit the perfect way to prevent cutting or somethign to sit on and hide it . btw all the labels r done by Hussein Samer Al Assi
        

        carComboBox = new JComboBox<>(cars.toArray(new Car[0]));
        carComboBox.setBackground(Color.WHITE);
        carComboBox.setForeground(new Color(0x333333));

        carSelectionPanel.add(new JLabel("Select Car:"));
        carSelectionPanel.add(carComboBox);
        controlPanel.add(carSelectionPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(6, 2, 10, 10));
        buttonPanel.setBackground(Color.WHITE);

        JButton rentButton = new JButton("Rent Car");
        rentButton.setFont(new Font("Arial", Font.PLAIN, 14));
        rentButton.setBackground(new Color(0x007BFF));
        rentButton.setForeground(Color.WHITE);
        rentButton.setFocusPainted(false);

        JButton returnButton = new JButton("Return Car");
        returnButton.setFont(new Font("Arial", Font.PLAIN, 14));
        returnButton.setBackground(new Color(0x007BFF));
        returnButton.setForeground(Color.WHITE);
        returnButton.setFocusPainted(false);

        JButton displayTransactionsButton = new JButton("Display Transactions");
        displayTransactionsButton.setFont(new Font("Arial", Font.PLAIN, 14));
        displayTransactionsButton.setBackground(new Color(0x007BFF));
        displayTransactionsButton.setForeground(Color.WHITE);
        displayTransactionsButton.setFocusPainted(false);

        JButton displayPricesButton = new JButton("Display Prices");
        displayPricesButton.setFont(new Font("Arial", Font.PLAIN, 14));
        displayPricesButton.setBackground(new Color(0x007BFF));
        displayPricesButton.setForeground(Color.WHITE);
        displayPricesButton.setFocusPainted(false);

        JButton addNewCarButton = new JButton("Add New Car");
        addNewCarButton.setFont(new Font("Arial", Font.PLAIN, 14));
        addNewCarButton.setBackground(new Color(0x007BFF));
        addNewCarButton.setForeground(Color.WHITE);
        addNewCarButton.setFocusPainted(false);

        JButton addNewClientButton = new JButton("Add New Client");
        addNewClientButton.setFont(new Font("Arial", Font.PLAIN, 14));
        addNewClientButton.setBackground(new Color(0x007BFF));
        addNewClientButton.setForeground(Color.WHITE);
        addNewClientButton.setFocusPainted(false);

        JButton backButtonMain = new JButton("Back");
        backButtonMain.setFont(new Font("Arial", Font.PLAIN, 14));
        backButtonMain.setBackground(new Color(0x007BFF));
        backButtonMain.setForeground(Color.WHITE);
        backButtonMain.setFocusPainted(false);

        buttonPanel.add(rentButton);
        buttonPanel.add(returnButton);
        buttonPanel.add(displayTransactionsButton);
        buttonPanel.add(displayPricesButton);
        buttonPanel.add(addNewCarButton);
        buttonPanel.add(addNewClientButton);
        buttonPanel.add(backButtonMain);
        controlPanel.add(buttonPanel, BorderLayout.CENTER);

        mainApplicationPanel.add(controlPanel, BorderLayout.SOUTH);

        rentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Car selectedCar = (Car) carComboBox.getSelectedItem();
                if (selectedCar != null && activeClient != null) {
                    selectedCar.rentCar(activeClient, textArea);
                } else {
                    JOptionPane.showMessageDialog(frame, "Please select a valid car and client.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Car selectedCar = (Car) carComboBox.getSelectedItem();
                if (selectedCar != null) {
                    selectedCar.returnCar(textArea);
                } else {
                    JOptionPane.showMessageDialog(frame, "Please select a valid car.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        displayTransactionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textArea.append("Transactions:\n");
                for (Car car : cars) {
                    textArea.append("Car: " + car.getName() + "\n");
                    car.printTransactions(textArea);
                    textArea.append("\n");
                }
            }
        });

        displayPricesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textArea.append("Car Prices:\n");
                for (Car car : cars) {
                    textArea.append("The " + car.getName() + " renting price is " + car.calculatePrice() + "\n");
                }
            }
        });

        addNewCarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAddNewCarPanel();
            }
        });

        addNewClientButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAddNewClientPanel();
            }
        });

        backButtonMain.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "ClientManagement");
            }
        });

        cardPanel.add(mainApplicationPanel, "MainApplication");

        // Add New Car Panel
        JPanel addNewCarPanel = new JPanel();
        addNewCarPanel.setLayout(new BorderLayout());
        addNewCarPanel.setBackground(Color.WHITE);
        addNewCarPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel carFormPanel = new JPanel();
        carFormPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        carFormPanel.setBackground(Color.WHITE);

        JLabel carNameLabel = new JLabel("Name:");
        carNameLabel.setForeground(new Color(0x333333));
        JTextField carNameField = new JTextField(20);
        JLabel carColorLabel = new JLabel("Color:");
        carColorLabel.setForeground(new Color(0x333333));
        JTextField carColorField = new JTextField(20);
        JLabel carChassisNumberLabel = new JLabel("Chassis Number:");
        carChassisNumberLabel.setForeground(new Color(0x333333));
        JTextField carChassisNumberField = new JTextField(20);
        JLabel carIdLabelAdd = new JLabel("Car ID:");
        carIdLabelAdd.setForeground(new Color(0x333333));
        JTextField carIdFieldAdd = new JTextField(20);
        JLabel carRegularRentingPriceLabel = new JLabel("Regular Renting Price:");
        carRegularRentingPriceLabel.setForeground(new Color(0x333333));
        JTextField carRegularRentingPriceField = new JTextField(20);
        JLabel carMaxAllowedRentingsLabel = new JLabel("Max Allowed Rentings:");
        carMaxAllowedRentingsLabel.setForeground(new Color(0x333333));
        JTextField carMaxAllowedRentingsField = new JTextField(20);
        JLabel carTypeLabel = new JLabel("Car Type:");
        carTypeLabel.setForeground(new Color(0x333333));
        JComboBox<String> carTypeComboBox = new JComboBox<>(new String[]{"NormalCar", "Bus"});
        carTypeComboBox.setBackground(Color.WHITE);
        carTypeComboBox.setForeground(new Color(0x333333));

        JPanel specificFieldsPanel = new JPanel();
        specificFieldsPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbcSpecific = new GridBagConstraints();
        gbcSpecific.insets = new Insets(5, 5, 5, 5);
        gbcSpecific.fill = GridBagConstraints.HORIZONTAL;
        specificFieldsPanel.setBackground(Color.WHITE);

        JLabel maxDurationOfRentLabel = new JLabel("Max Duration of Rent:");
        maxDurationOfRentLabel.setForeground(new Color(0x333333));
        JTextField maxDurationOfRentField = new JTextField(20);
        JLabel discountLabel = new JLabel("Discount (%):");
        discountLabel.setForeground(new Color(0x333333));
        JTextField discountField = new JTextField(20);
        JLabel capacityLabel = new JLabel("Capacity:");
        capacityLabel.setForeground(new Color(0x333333));
        JTextField capacityField = new JTextField(20);

        carTypeComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                specificFieldsPanel.removeAll();
                if (carTypeComboBox.getSelectedItem().equals("NormalCar")) {
                    specificFieldsPanel.add(maxDurationOfRentLabel, gbcSpecific);
                    specificFieldsPanel.add(maxDurationOfRentField, gbcSpecific);
                    specificFieldsPanel.add(discountLabel, gbcSpecific);
                    specificFieldsPanel.add(discountField, gbcSpecific);
                } else if (carTypeComboBox.getSelectedItem().equals("Bus")) {
                    specificFieldsPanel.add(capacityLabel, gbcSpecific);
                    specificFieldsPanel.add(capacityField, gbcSpecific);
                }
                specificFieldsPanel.revalidate();
                specificFieldsPanel.repaint();
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        carFormPanel.add(carNameLabel, gbc);
        gbc.gridx = 1;
        carFormPanel.add(carNameField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        carFormPanel.add(carColorLabel, gbc);
        gbc.gridx = 1;
        carFormPanel.add(carColorField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        carFormPanel.add(carChassisNumberLabel, gbc);
        gbc.gridx = 1;
        carFormPanel.add(carChassisNumberField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        carFormPanel.add(carIdLabelAdd, gbc);
        gbc.gridx = 1;
        carFormPanel.add(carIdFieldAdd, gbc);
        gbc.gridx = 0;
        gbc.gridy = 4;
        carFormPanel.add(carRegularRentingPriceLabel, gbc);
        gbc.gridx = 1;
        carFormPanel.add(carRegularRentingPriceField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 5;
        carFormPanel.add(carMaxAllowedRentingsLabel, gbc);
        gbc.gridx = 1;
        carFormPanel.add(carMaxAllowedRentingsField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 6;
        carFormPanel.add(carTypeLabel, gbc);
        gbc.gridx = 1;
        carFormPanel.add(carTypeComboBox, gbc);
        gbc.gridx = 0;
        gbc.gridy = 7;
        carFormPanel.add(new JLabel("Specific Fields:"), gbc);
        gbc.gridx = 1;
        carFormPanel.add(specificFieldsPanel, gbc);

        JPanel buttonPanelAddCar = new JPanel();
        buttonPanelAddCar.setLayout(new FlowLayout(FlowLayout.RIGHT));
        buttonPanelAddCar.setBackground(Color.WHITE);

        JButton addCarButton = new JButton("Add Car");
        addCarButton.setBackground(new Color(0x007BFF));
        addCarButton.setForeground(Color.WHITE);
        addCarButton.setFocusPainted(false);

        JButton backButtonAddCar = new JButton("Back");
        backButtonAddCar.setBackground(new Color(0x007BFF));
        backButtonAddCar.setForeground(Color.WHITE);
        backButtonAddCar.setFocusPainted(false);

        buttonPanelAddCar.add(addCarButton);
        buttonPanelAddCar.add(backButtonAddCar);
        addNewCarPanel.add(carFormPanel, BorderLayout.CENTER);
        addNewCarPanel.add(buttonPanelAddCar, BorderLayout.SOUTH);

        addCarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = carNameField.getText();
                String color = carColorField.getText();
                String chassisNumberText = carChassisNumberField.getText();
                String idText = carIdFieldAdd.getText();
                String regularRentingPriceText = carRegularRentingPriceField.getText();
                String maxAllowedRentingsText = carMaxAllowedRentingsField.getText();
                String carType = (String) carTypeComboBox.getSelectedItem();
                if (name.isEmpty() || color.isEmpty() || chassisNumberText.isEmpty() || idText.isEmpty() || regularRentingPriceText.isEmpty() || maxAllowedRentingsText.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                    int chassisNumber = Integer.parseInt(chassisNumberText);
                    int id = Integer.parseInt(idText);
                    double regularRentingPrice = Double.parseDouble(regularRentingPriceText);
                    int maxAllowedRentings = Integer.parseInt(maxAllowedRentingsText);
                    for (Car car : cars) {
                        if (car.getId() == id) {
                            JOptionPane.showMessageDialog(frame, "Car ID already exists. Please use a different ID.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                    }
                    Car newCar;
                    if (carType.equals("NormalCar")) {
                        int maxDurationOfRent = Integer.parseInt(maxDurationOfRentField.getText());
                        double discount = Double.parseDouble(discountField.getText());
                        newCar = new NormalCar(name, color, chassisNumber, id, regularRentingPrice, maxAllowedRentings, maxDurationOfRent, discount);
                    } else {
                        int capacity = Integer.parseInt(capacityField.getText());
                        newCar = new Bus(name, color, chassisNumber, id, regularRentingPrice, maxAllowedRentings, capacity);
                    }
                    cars.add(newCar);
                    carComboBox.addItem(newCar); // Update the carComboBox with the new car
                    JOptionPane.showMessageDialog(frame, "Car added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    cardLayout.show(cardPanel, "MainApplication");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid number format. Please check your inputs.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        backButtonAddCar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "MainApplication");
            }
        });

        cardPanel.add(addNewCarPanel, "AddNewCar");

        // Add New Client Panel
        JPanel addNewClientPanel = new JPanel();
        addNewClientPanel.setLayout(new BorderLayout());
        addNewClientPanel.setBackground(Color.WHITE);
        addNewClientPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel clientFormPanel = new JPanel();
        clientFormPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbcClient = new GridBagConstraints();
        gbcClient.insets = new Insets(5, 5, 5, 5);
        gbcClient.fill = GridBagConstraints.HORIZONTAL;
        clientFormPanel.setBackground(Color.WHITE);

        JLabel clientNameLabel = new JLabel("Name:");
        clientNameLabel.setForeground(new Color(0x333333));
        JTextField clientNameField = new JTextField(20);
        JLabel clientSSNLabel = new JLabel("SSN:");
        clientSSNLabel.setForeground(new Color(0x333333));
        JTextField clientSSNField = new JTextField(20);
        JLabel clientPhoneLabel = new JLabel("Phone:");
        clientPhoneLabel.setForeground(new Color(0x333333));
        JTextField clientPhoneField = new JTextField(20);
        JLabel clientAddressLabel = new JLabel("Address:");
        clientAddressLabel.setForeground(new Color(0x333333));
        JTextField clientAddressField = new JTextField(20);

        gbcClient.gridx = 0;
        gbcClient.gridy = 0;
        clientFormPanel.add(clientNameLabel, gbcClient);
        gbcClient.gridx = 1;
        clientFormPanel.add(clientNameField, gbcClient);
        gbcClient.gridx = 0;
        gbcClient.gridy = 1;
        clientFormPanel.add(clientSSNLabel, gbcClient);
        gbcClient.gridx = 1;
        clientFormPanel.add(clientSSNField, gbcClient);
        gbcClient.gridx = 0;
        gbcClient.gridy = 2;
        clientFormPanel.add(clientPhoneLabel, gbcClient);
        gbcClient.gridx = 1;
        clientFormPanel.add(clientPhoneField, gbcClient);
        gbcClient.gridx = 0;
        gbcClient.gridy = 3;
        clientFormPanel.add(clientAddressLabel, gbcClient);
        gbcClient.gridx = 1;
        clientFormPanel.add(clientAddressField, gbcClient);

        JPanel buttonPanelAddClient = new JPanel();
        buttonPanelAddClient.setLayout(new FlowLayout(FlowLayout.RIGHT));
        buttonPanelAddClient.setBackground(Color.WHITE);

        JButton addClientButton = new JButton("Add Client");
        addClientButton.setBackground(new Color(0x007BFF));
        addClientButton.setForeground(Color.WHITE);
        addClientButton.setFocusPainted(false);

        JButton backButtonAddClient = new JButton("Back");
        backButtonAddClient.setBackground(new Color(0x007BFF));
        backButtonAddClient.setForeground(Color.WHITE);
        backButtonAddClient.setFocusPainted(false);

        buttonPanelAddClient.add(addClientButton);
        buttonPanelAddClient.add(backButtonAddClient);
        addNewClientPanel.add(clientFormPanel, BorderLayout.CENTER);
        addNewClientPanel.add(buttonPanelAddClient, BorderLayout.SOUTH);

        addClientButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = clientNameField.getText();
                String ssnText = clientSSNField.getText();
                String phone = clientPhoneField.getText();
                String address = clientAddressField.getText();
                if (name.isEmpty() || ssnText.isEmpty() || phone.isEmpty() || address.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                    int ssn = Integer.parseInt(ssnText);
                    for (Client client : clients) {
                        if (client.getSsn() == ssn) {
                            JOptionPane.showMessageDialog(frame, "SSN already exists. Please use a different SSN.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                    }
                    Client newClient = new Client(name, ssn, phone, address);
                    clients.add(newClient);
                    JOptionPane.showMessageDialog(frame, "Registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    cardLayout.show(cardPanel, "MainApplication");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid SSN format. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        backButtonAddClient.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "MainApplication");
            }
        });

        cardPanel.add(addNewClientPanel, "AddNewClient");

        // Add window close listener to save data before exiting
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                FileIO.saveClients(clients, "Client.dat");
                FileIO.saveCars(cars, "Car.dat");
                JOptionPane.showMessageDialog(frame, "Data saved successfully!");
            }
        });

        frame.setVisible(true);
    }

    private void showMainApplicationPanel(Client client) {
        activeClient = client;
        cardLayout.show(cardPanel, "MainApplication");
    }

    private void showAddNewCarPanel() {
        cardLayout.show(cardPanel, "AddNewCar");
    }

    private void showAddNewClientPanel() {
        cardLayout.show(cardPanel, "AddNewClient");
    }

    public static void main(String[] args) {
        // Load data from files
        ArrayList<Client> clients = FileIO.loadClients("Client.dat");
        ArrayList<Car> cars = FileIO.loadCars("Car.dat");

        // Initialize data if files are empty
        if (clients.isEmpty()) {
            clients.add(new Client("John Doe", 123456789, "123-456-7890", "123 Elm St"));
            clients.add(new Client("Jane Smith", 987654321, "987-654-3210", "456 Oak St"));
            clients.add(new Client("Alice Johnson", 112233445, "555-123-4567", "789 Pine St"));
        }
        if (cars.isEmpty()) {
            cars.add(new NormalCar("Toyota Camry", "Red", 1001, 1, 50.0, 10, 7, 10));
            cars.add(new NormalCar("Honda Accord", "Blue", 1002, 2, 55.0, 10, 7, 15));
            cars.add(new Bus("School Bus", "Yellow", 1003, 3, 100.0, 5, 30));
            cars.add(new Bus("City Bus", "Green", 1004, 4, 80.0, 5, 40));
            cars.add(new NormalCar("Ford Mustang", "Black", 1005, 5, 75.0, 10, 5, 20));
        }

        // Create the GUI finally
        SwingUtilities.invokeLater(() -> new CarRentCompanyGUI(clients, cars));
    }
}