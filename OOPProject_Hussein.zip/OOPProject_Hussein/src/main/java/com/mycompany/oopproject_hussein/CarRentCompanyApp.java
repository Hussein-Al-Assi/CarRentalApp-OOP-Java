package com.mycompany.oopproject_hussein;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Date;

public class CarRentCompanyApp {

    public static void main(String[] args) {
        // Load data from files
        ArrayList<Client> clients = FileIO.loadClients("Client.dat");
        ArrayList<Car> cars = FileIO.loadCars("Car.dat");

        // Initialize data if files are empty
        if (clients.isEmpty()) {
            clients.add(new Client("John Doe", 123456789, "123-456-7890", "123 Elm St"));
            clients.add(new Client("Jane Smith", 987654321, "987-654-3210", "456 Oak St"));
            clients.add(new Client("Alice Johnson", 112233445, "555-123-4567", "789 Pine St"));
        }

        if (cars.isEmpty()) {
            cars.add(new NormalCar("Toyota Camry", "Red", 1001, 1, 50.0, 10, 7, 10));
            cars.add(new NormalCar("Honda Accord", "Blue", 1002, 2, 55.0, 10, 7, 15));
            cars.add(new Bus("School Bus", "Yellow", 1003, 3, 100.0, 5, 30));
            cars.add(new Bus("City Bus", "Green", 1004, 4, 80.0, 5, 40));
            cars.add(new NormalCar("Ford Mustang", "Black", 1005, 5, 75.0, 10, 5, 20));
        }

        // Create the GUI
        SwingUtilities.invokeLater(() -> new CarRentCompanyGUI(clients, cars));
    }
}