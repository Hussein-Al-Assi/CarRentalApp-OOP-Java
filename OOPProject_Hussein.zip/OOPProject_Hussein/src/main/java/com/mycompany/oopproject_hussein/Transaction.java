
package com.mycompany.oopproject_hussein;
import java.io.Serializable;
import java.util.Date;

public class Transaction implements Comparable<Transaction>, Serializable {
    //One counter for the entire class (not per object).
    private static int transactionCounter = 0;
    private int transactionNumber;
    private Car rentedCar;
    private Client client;
    private Date transactionDate;
    private double rentingPrice;

    public Transaction(Car rentedCar, Client client, Date transactionDate) {
        /*Why ++transactionCounter?

     Prefix ++ → Increments before assigning (e.g., transactionCounter=0 → transactionNumber=1).*/
        
        this.transactionNumber = ++transactionCounter;
        this.rentedCar = rentedCar;
        this.client = client;
        this.transactionDate = transactionDate;
        this.rentingPrice = rentedCar.calculatePrice();
    }

    // Getters and Setters
    public int getTransactionNumber() { return transactionNumber; }
    public Car getRentedCar() { return rentedCar; }
    public Client getClient() { return client; }
    public Date getTransactionDate() { return transactionDate; }
    public double getRentingPrice() { return rentingPrice; }

    @Override
    public String toString() {
        return "Transaction{" +
                "transactionNumber=" + transactionNumber +
                ", rentedCar=" + rentedCar.getName() +
                ", client=" + client.getName();
    }

    //compared by date
@Override
public int compareTo(Transaction other) {
    return this.transactionDate.compareTo(other.transactionDate);
}
}
