package com.mycompany.oopproject_hussein;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JTextArea;

public abstract class Car implements Serializable {
    private String name;
    private String color;
    private int id;
    private int chassisNumber;
    
     // Rental Management
    private boolean isAvailable;
    private double regularRentingPrice;
    private int timesRented;
    private int maxAllowedRentings;
    private Date ownershipDate;
    
      // Transactions
    private ArrayList<Transaction> transactions;

    public Car(String name, String color, int chassisNumber, int id, double regularRentingPrice, int maxAllowedRentings) {
        this.name = name;
        this.color = color;
        this.chassisNumber = chassisNumber;
        this.id = id;
        this.regularRentingPrice = regularRentingPrice;
        this.maxAllowedRentings = maxAllowedRentings;
        this.isAvailable = true;
        this.timesRented = 0;
        this.ownershipDate = new Date();
        this.transactions = new ArrayList<>();
    }

    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getChassisNumber() { return chassisNumber; }
    public void setChassisNumber(int chassisNumber) { this.chassisNumber = chassisNumber; }
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { this.isAvailable = available; }
    public double getRegularRentingPrice() { return regularRentingPrice; }
    public void setRegularRentingPrice(double regularRentingPrice) { this.regularRentingPrice = regularRentingPrice; }
    public int getTimesRented() { return timesRented; }
    public void setTimesRented(int timesRented) { this.timesRented = timesRented; }
    public int getMaxAllowedRentings() { return maxAllowedRentings; }
    public void setMaxAllowedRentings(int maxAllowedRentings) { this.maxAllowedRentings = maxAllowedRentings; }
    public Date getOwnershipDate() { return ownershipDate; }
    public void setOwnershipDate(Date ownershipDate) { this.ownershipDate = ownershipDate; }
    public ArrayList<Transaction> getTransactions() { return transactions; }
    public void setTransactions(ArrayList<Transaction> transactions) { this.transactions = transactions; }

    // Methods
    
    //This method rents a car to a client, creates a transaction, and writes a message in the text area.
    public void rentCar(Client client, JTextArea textArea) {
        if (isAvailable) {
            if (timesRented < maxAllowedRentings) {
                isAvailable = false;
                timesRented++;
                Transaction transaction = new Transaction(this, client, new Date());
                
                transactions.add(transaction);
                // Adds the new transaction to the car’s list of transactions.
                textArea.append("Car " + name + " rented to " + client.getName() + "\n");
            } else {
                textArea.append("Maximum allowed number of rentals exceeded.\n");
            }
        } else {
            textArea.append("The car is already rented.\n");
        }
    }

    public void returnCar(JTextArea textArea) {
        if (!isAvailable) {
            isAvailable = true;
            textArea.append("Car " + name + " returned.\n");
        } else {
            textArea.append("This car is not rented, then you cannot return it.\n");
        }
    }

    public abstract double calculatePrice();

    public void printTransactions(JTextArea textArea) {
           // 1. Loop through every Transaction in the 'transactions' list
        for (Transaction transaction : transactions) {
            //Note: Enhanced for Loop:
            // for (Transaction t : transactions) means:
            //"For each Transaction object (which we'll call t) in the transactions list..."
    /* same as for (int i = 0; i < transactions.size(); i++) {
    Transaction t = transactions.get(i);
    }*/
               // 2. Convert Transaction to String and add to textArea
            textArea.append(transaction.toString() + "\n");
        }
    }

    public void displayTransDates(Date d1, Date d2, JTextArea textArea) {
        for (Transaction transaction : transactions) {
            Date transactionDate = transaction.getTransactionDate();
            if (!transactionDate.before(d1) && !transactionDate.after(d2)) {
                textArea.append(transaction.toString() + "\n");
            }
        }
    }

    @Override
    public String toString() {
        return "Car{" +
                "name='" + name + '\'' +
                ", color='" + color + '\'' +
                ", id=" + id +
                ", chassisNumber=" + chassisNumber +
                ", isAvailable=" + isAvailable +
                ", regularRentingPrice=" + regularRentingPrice +
                ", timesRented=" + timesRented +
                ", maxAllowedRentings=" + maxAllowedRentings +
                ", ownershipDate=" + ownershipDate +
                '}';
    }
}