
package com.mycompany.oopproject_hussein;
import java.io.Serializable;

public class NormalCar extends Car implements Serializable {
    private int maxDurationOfRent;
    private double discount;

    public NormalCar(String name, String color, int chassisNumber, int id, double regularRentingPrice, int maxAllowedRentings, int maxDurationOfRent, double discount) {
        super(name, color, chassisNumber, id, regularRentingPrice, maxAllowedRentings);
        this.maxDurationOfRent = maxDurationOfRent;
        this.discount = discount;
    }

    // Getters and Setters
    public int getMaxDurationOfRent() { return maxDurationOfRent; }
    public void setMaxDurationOfRent(int maxDurationOfRent) { this.maxDurationOfRent = maxDurationOfRent; }
    public double getDiscount() { return discount; }
    public void setDiscount(double discount) { this.discount = discount; }

    @Override
    public double calculatePrice() {

    // Remaining usage ratio: how much renting availability is left
    double availabilityFactor = 1 - (getTimesRented() / (double) getMaxAllowedRentings());

    // Discount factor: converts percentage to a decimal (e.g., 20% → 0.8)
    double discountFactor = 1 - discount / 100.0;

    // Final price = base price × availability × discount
    return getRegularRentingPrice() * availabilityFactor * discountFactor;
}


    

    @Override
    public String toString() {
        return "NormalCar{" +
                "maxDurationOfRent=" + maxDurationOfRent +
                ", discount=" + discount +
                "} " + super.toString();
    }
}