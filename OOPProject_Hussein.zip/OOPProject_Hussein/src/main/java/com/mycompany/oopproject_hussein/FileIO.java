
package com.mycompany.oopproject_hussein;

import java.io.*;
import java.util.ArrayList;

public class FileIO {
    /*Why Parameters in Methods?
    Parameters let you pass data into the method when calling it:*/
    
    /*Why Static Methods?
No need to create a FileIO object. Call directly:*/
    
    public static void saveClients(ArrayList<Client> clients, String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            //below is the serialization it converts the entire Arraylist client to binary format ..
            oos.writeObject(clients);
        } catch (IOException e) {
           System.out.println("Errorr: Failed to save clients");
    }//Auto-closeable
        
        
    }
    public static ArrayList<Client> loadClients(String fileName) {
        ArrayList<Client> clients = new ArrayList<>();
        //creates empty list as fallback if loading fails
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            clients = (ArrayList<Client>) ois.readObject();//casting the object 
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Failed to load clients file OR  Class version...File may be corrupted or missing");
        }
        return clients;
    }

    public static void saveCars(ArrayList<Car> cars, String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(cars);
        } catch (IOException e) {
            System.out.println("Car data save failed ");
        }
    }

    public static ArrayList<Car> loadCars(String fileName) {
        ArrayList<Car> cars = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            cars = (ArrayList<Car>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading cars OR Invalid class format ");
        }
        return cars;
    }
}